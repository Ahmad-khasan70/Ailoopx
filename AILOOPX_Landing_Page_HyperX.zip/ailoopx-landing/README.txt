AILOOPX - LANDING PAGE PROMOSI & EDUKASI
HyperX Academy | Versi 1.0 | 21 November 2026

ISI BERKAS
- index.html      : halaman utama
- styles.css      : semua gaya desktop dan mobile
- script.js       : konfigurasi tautan WhatsApp, referral, dan form
- assets/         : ikon dan gambar preview sosial

CARA MEMBUKA
1. Ekstrak file ZIP.
2. Buka index.html di Chrome/Edge/Firefox.
3. Upload semua file/folder (jaga strukturnya) ke hosting, Netlify, GitHub Pages, atau Vercel static site.

SEBELUM PUBLIKASI (WAJIB DIPERIKSA)
1. Buka script.js dan edit CONFIG.whatsappNumber menjadi nomor WA admin dengan format 62... tanpa +.
   Saat ini: 6285606065665 (diambil dari materi Ailoopx.pdf terdahulu, BELUM dikonfirmasi nomor admin final).
2. Edit CONFIG.registrationUrl menjadi tautan referral milik Anda.
   Saat ini: https://ailoopx.com/?ref=R75C672F53 (dari materi Ailoopx.pdf terdahulu).
   Sifat dan keaktifan situs tersebut belum dapat diverifikasi pada saat pembuatan.
3. Periksa ulang biaya aktivasi, fitur AI, biaya USDA+, syarat Matrix, dan aturan penarikan di sumber resmi terkini.
4. Logo X/wordmark yang dipakai adalah ilustrasi sementara yang dibuat untuk halaman ini,
   bukan rekonstruksi persis dari logo master AILOOPX. Ganti dengan file logo resmi berizin bila tersedia.
5. Font Google Fonts memerlukan koneksi internet. Jika offline, tampilan menggunakan fallback bawaan.
6. OG preview sudah tersedia dalam format PNG; setelah situs memiliki domain, ubah og:image menjadi URL absolut untuk dukungan media sosial terbaik.

CARA KERJA FORM
- Pengunjung mengetik nama/topik/pertanyaan.
- Browser menyusun pesan dan membuka chat WhatsApp ke nomor dalam CONFIG.
- Tidak ada backend; tidak ada data yang dikirim/disimpan ke server landing page.
- Pengunjung harus menekan KIRIM sendiri di WhatsApp.

CATATAN ETIKA PROMOSI
- Tidak berisi angka pengunjung/testimoni fiktif, countdown palsu, atau garansi pendapatan.
- USDA+ disebut saldo internal, bukan klaim token kripto yang bebas ditarik.
- Tidak ada sistem pembayaran atau koneksi wallet pada website ini.
- Materi edukasi HyperX Academy, bukan situs resmi AILOOPX.
