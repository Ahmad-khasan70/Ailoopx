/*
 * KONFIGURASI UTAMA LANDING PAGE AILOOPX
 * Periksa nomor WhatsApp dan kode referral sebelum website dipublikasikan.
 * Nomor berformat kode negara tanpa tanda +, misalnya 6281234567890.
 * Nilai di bawah berasal dari materi promosi AILOOPX yang telah dibagikan.
 */
const CONFIG = {
  whatsappNumber: '6285606065665',
  registrationUrl: 'https://ailoopx.com/?ref=R75C672F53',
  whatsappIntro: 'Halo Admin HyperX Academy, saya melihat informasi AILOOPX dari landing page dan ingin bertanya.'
};

const menuToggle = document.getElementById('menu-toggle');
const navMenu = document.getElementById('nav-menu');
const toastEl = document.getElementById('toast');
let toastTimeout;

function toast(message) {
  clearTimeout(toastTimeout);
  toastEl.textContent = message;
  toastEl.classList.add('show');
  toastTimeout = setTimeout(() => toastEl.classList.remove('show'), 5000);
}

function getWhatsAppUrl(message) {
  const number = (CONFIG.whatsappNumber || '').replace(/[^0-9]/g, '');
  const base = number ? `https://wa.me/${number}` : 'https://wa.me/';
  return `${base}?text=${encodeURIComponent(message)}`;
}

menuToggle.addEventListener('click', () => {
  const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
  menuToggle.setAttribute('aria-expanded', String(!expanded));
  navMenu.classList.toggle('open', !expanded);
  menuToggle.setAttribute('aria-label', expanded ? 'Buka menu navigasi' : 'Tutup menu navigasi');
});

navMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  navMenu.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Buka menu navigasi');
}));

document.querySelectorAll('[data-registration-link]').forEach(link => {
  link.href = CONFIG.registrationUrl || 'https://ailoopx.com';
});

document.getElementById('lead-form').addEventListener('submit', event => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;
  const name = document.getElementById('lead-name').value.trim();
  const interest = document.getElementById('lead-interest').value;
  const question = document.getElementById('lead-question').value.trim();
  const message = [
    CONFIG.whatsappIntro,
    '',
    `Nama: ${name}`,
    `Topik: ${interest}`,
    question ? `Pertanyaan: ${question}` : null,
    '',
    'Mohon informasi dan penjelasan sebelum saya mengambil keputusan.'
  ].filter(line => line !== null).join('\n');
  const url = getWhatsAppUrl(message);
  const opened = window.open(url, '_blank');
  if (!opened) window.location.href = url;
  toast('WhatsApp dibuka. Pesan baru terkirim setelah Anda menekan tombol Kirim di WhatsApp.');
});

document.getElementById('year').textContent = new Date().getFullYear();

// Menjaga navigasi ramah keyboard pada penggunaan mobile.
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && navMenu.classList.contains('open')) {
    navMenu.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.focus();
  }
});
